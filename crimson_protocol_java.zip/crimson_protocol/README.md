# CRIMSON PROTOCOL

A self-contained Java 17 desktop survival shooter built with Swing and Java2D.

## Requirements
- JDK 17 or newer
- No external dependencies

## Run
From the project root:

```bash
javac -d out src/main/java/com/carter/crimson/*.java
java -cp out com.carter.crimson.Game
```

## Controls
- WASD or Arrow keys: move
- Space: fire
- Shift: boost movement
- P or Escape: pause/resume
- Enter: start/restart

## Gameplay
Destroy incoming drones, avoid collisions, collect repair cells, and survive escalating waves. Each defeated enemy adds score; clearing a wave awards a bonus.

## Project structure
- `Game.java`: application window, game loop, state management, rendering and input
- `Player.java`: player ship
- `Enemy.java`: hostile drone behavior
- `Bullet.java`: projectile model
- `Pickup.java`: repair power-up
- `Particle.java`: impact effects
