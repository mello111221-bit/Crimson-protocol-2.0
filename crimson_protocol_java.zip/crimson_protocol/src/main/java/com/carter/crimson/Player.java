package com.carter.crimson;
import java.awt.*;
final class Player {
    double x,y; int hp=100; final int radius=17;
    Player(double x,double y){this.x=x;this.y=y;}
    void draw(Graphics2D g){
        g.setColor(new Color(255,35,65,55)); g.fillOval((int)x-27,(int)y-27,54,54);
        Polygon p=new Polygon(new int[]{(int)x,(int)x-17,(int)x,(int)x+17},
                              new int[]{(int)y-22,(int)y+17,(int)y+9,(int)y+17},4);
        g.setColor(new Color(255,55,80)); g.fillPolygon(p);
        g.setColor(Color.WHITE); g.drawPolygon(p);
        g.setColor(new Color(255,180,190)); g.fillOval((int)x-3,(int)y-7,6,9);
    }
}
