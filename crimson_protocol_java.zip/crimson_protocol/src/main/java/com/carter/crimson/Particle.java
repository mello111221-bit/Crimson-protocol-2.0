package com.carter.crimson;
import java.awt.*;
final class Particle {
    double x,y,vx,vy; int life=28; final Color color;
    Particle(double x,double y,double vx,double vy,Color c){this.x=x;this.y=y;this.vx=vx;this.vy=vy;color=c;}
    void update(){x+=vx;y+=vy;vx*=.96;vy*=.96;life--;}
    void draw(Graphics2D g){g.setColor(new Color(color.getRed(),color.getGreen(),color.getBlue(),Math.max(0,life*8)));g.fillOval((int)x,(int)y,4,4);}
}
