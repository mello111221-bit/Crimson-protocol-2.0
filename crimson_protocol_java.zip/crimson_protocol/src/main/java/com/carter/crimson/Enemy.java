package com.carter.crimson;
import java.awt.*;
final class Enemy {
    double x,y; int hp; final int radius=17; boolean dead; double phase;
    Enemy(double x,double y,int wave){this.x=x;this.y=y;hp=1+wave/4;phase=x*.03;}
    void update(double px,double py){
        y+=1.25+Math.min(2.5,hp*.25);
        x+=Math.sin(y*.025+phase)*1.2;
    }
    void draw(Graphics2D g){
        g.setColor(new Color(255,45,55,55));g.fillOval((int)x-25,(int)y-25,50,50);
        g.setColor(new Color(145,28,48));
        Polygon p=new Polygon(new int[]{(int)x,(int)x-18,(int)x-12,(int)x+12,(int)x+18},
                              new int[]{(int)y+19,(int)y-9,(int)y-19,(int)y-19,(int)y-9},5);
        g.fillPolygon(p);g.setColor(new Color(255,100,115));g.drawPolygon(p);
        g.setColor(Color.WHITE);g.fillRect((int)x-5,(int)y-4,10,5);
    }
}
