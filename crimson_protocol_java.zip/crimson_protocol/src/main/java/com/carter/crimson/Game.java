package com.carter.crimson;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public final class Game extends JPanel implements ActionListener, KeyListener {
    static final int W = 960, H = 640;
    private final Timer timer = new Timer(16, this);
    private final Random random = new Random();
    private final List<Bullet> bullets = new ArrayList<>();
    private final List<Enemy> enemies = new ArrayList<>();
    private final List<Pickup> pickups = new ArrayList<>();
    private final List<Particle> particles = new ArrayList<>();
    private final boolean[] keys = new boolean[512];
    private final Player player = new Player(W / 2.0, H - 90);
    private GameState state = GameState.MENU;
    private int score, wave = 1, waveKills, spawnCooldown, shake;
    private long lastShot, lastDamage;
    private String banner = "";
    private int bannerTicks;
    private final Font titleFont = new Font("Dialog", Font.BOLD, 54);
    private final Font uiFont = new Font("Monospaced", Font.BOLD, 16);

    enum GameState { MENU, PLAYING, PAUSED, GAME_OVER }

    public Game() {
        setPreferredSize(new Dimension(W, H));
        setBackground(new Color(5, 7, 13));
        setFocusable(true);
        addKeyListener(this);
        timer.start();
    }

    @Override public void actionPerformed(ActionEvent e) {
        if (state == GameState.PLAYING) updateGame();
        repaint();
    }

    private void startGame() {
        bullets.clear(); enemies.clear(); pickups.clear(); particles.clear();
        player.x = W / 2.0; player.y = H - 90; player.hp = 100;
        score = 0; wave = 1; waveKills = 0; spawnCooldown = 30;
        state = GameState.PLAYING;
        announce("INCOMING HOSTILES");
    }

    private void updateGame() {
        double speed = (keys[KeyEvent.VK_SHIFT] ? 5.2 : 4.0);
        double dx = 0, dy = 0;
        if (down(KeyEvent.VK_A) || down(KeyEvent.VK_LEFT)) dx--;
        if (down(KeyEvent.VK_D) || down(KeyEvent.VK_RIGHT)) dx++;
        if (down(KeyEvent.VK_W) || down(KeyEvent.VK_UP)) dy--;
        if (down(KeyEvent.VK_S) || down(KeyEvent.VK_DOWN)) dy++;
        if (dx != 0 && dy != 0) { dx *= 0.7071; dy *= 0.7071; }
        player.x = clamp(player.x + dx * speed, 24, W - 24);
        player.y = clamp(player.y + dy * speed, 70, H - 28);

        if (down(KeyEvent.VK_SPACE) && System.currentTimeMillis() - lastShot > 180) {
            bullets.add(new Bullet(player.x, player.y - 22, 0, -10, true));
            lastShot = System.currentTimeMillis();
        }

        if (--spawnCooldown <= 0) {
            int count = Math.min(1 + wave / 3, 4);
            for (int i = 0; i < count; i++) {
                double x = 55 + random.nextInt(W - 110);
                enemies.add(new Enemy(x, -30 - i * 42, wave));
            }
            spawnCooldown = Math.max(22, 78 - wave * 4);
        }

        for (Bullet b : bullets) b.update();
        for (Enemy en : enemies) {
            en.update(player.x, player.y);
            if (en.y > H + 30) { en.dead = true; player.hp -= 8; shake = 8; }
            if (distance(en.x, en.y, player.x, player.y) < en.radius + player.radius) {
                en.dead = true; damagePlayer(18);
                burst(player.x, player.y, new Color(255, 65, 75), 16);
            }
        }

        Iterator<Bullet> bi = bullets.iterator();
        while (bi.hasNext()) {
            Bullet b = bi.next();
            if (b.dead || b.y < -20 || b.y > H + 20) { bi.remove(); continue; }
            if (b.friendly) {
                for (Enemy en : enemies) {
                    if (!en.dead && distance(b.x, b.y, en.x, en.y) < en.radius + 6) {
                        en.hp -= 1; b.dead = true;
                        burst(b.x, b.y, new Color(255, 55, 75), 5);
                        if (en.hp <= 0) {
                            en.dead = true; score += 100 + wave * 15; waveKills++;
                            burst(en.x, en.y, new Color(255, 85, 95), 18);
                            if (random.nextDouble() < .13) pickups.add(new Pickup(en.x, en.y));
                        }
                        break;
                    }
                }
            } else if (distance(b.x, b.y, player.x, player.y) < player.radius + 5) {
                b.dead = true; damagePlayer(10);
            }
        }
        enemies.removeIf(en -> en.dead);
        bullets.removeIf(b -> b.dead);
        pickups.removeIf(p -> {
            p.y += 2.1;
            if (distance(p.x, p.y, player.x, player.y) < 25) {
                player.hp = Math.min(100, player.hp + 22);
                announce("REPAIR CELL +22");
                burst(p.x, p.y, new Color(70, 255, 170), 14);
                return true;
            }
            return p.y > H + 20;
        });
        particles.removeIf(p -> { p.update(); return p.life <= 0; });

        if (waveKills >= wave * 7 && enemies.isEmpty()) {
            wave++; waveKills = 0; spawnCooldown = 65;
            announce("WAVE " + wave);
            score += 250 * wave;
        }
        if (player.hp <= 0) { player.hp = 0; state = GameState.GAME_OVER; }
        if (bannerTicks > 0) bannerTicks--;
        if (shake > 0) shake--;
    }

    private void damagePlayer(int amount) {
        if (System.currentTimeMillis() - lastDamage < 500) return;
        player.hp -= amount; lastDamage = System.currentTimeMillis(); shake = 10;
    }

    private void announce(String text) { banner = text; bannerTicks = 100; }
    private boolean down(int key) { return key < keys.length && keys[key]; }
    private static double clamp(double v, double min, double max) { return Math.max(min, Math.min(max, v)); }
    private static double distance(double x1, double y1, double x2, double y2) { return Math.hypot(x1-x2, y1-y2); }

    private void burst(double x, double y, Color c, int amount) {
        for (int i=0; i<amount; i++) {
            double a = random.nextDouble() * Math.PI * 2, s = 1 + random.nextDouble() * 4;
            particles.add(new Particle(x, y, Math.cos(a)*s, Math.sin(a)*s, c));
        }
    }

    @Override protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        if (shake > 0) g.translate(random.nextInt(shake+1)-shake/2, random.nextInt(shake+1)-shake/2);
        drawBackground(g);
        if (state == GameState.MENU) drawMenu(g);
        else {
            for (Pickup p : pickups) p.draw(g);
            for (Bullet b : bullets) b.draw(g);
            for (Enemy en : enemies) en.draw(g);
            for (Particle p : particles) p.draw(g);
            player.draw(g);
            drawHud(g);
            if (state == GameState.PAUSED) overlay(g, "PAUSED", "Press P to resume");
            if (state == GameState.GAME_OVER) overlay(g, "SYSTEM FAILURE", "Score: " + score + "   •   Press ENTER to retry");
        }
        g.dispose();
    }

    private void drawBackground(Graphics2D g) {
        g.setColor(new Color(5, 7, 13)); g.fillRect(0,0,W,H);
        g.setColor(new Color(22, 27, 43));
        for (int x=0; x<W; x+=48) g.drawLine(x,0,x,H);
        for (int y=0; y<H; y+=48) g.drawLine(0,y,W,y);
        g.setColor(new Color(255, 35, 65, 90));
        g.drawLine(0, H/2, W, H/2);
        for (int i=0; i<70; i++) {
            int x = (i*137) % W, y = (i*83 + (int)(System.currentTimeMillis()/40)) % H;
            g.setColor(new Color(130, 150, 190, 70)); g.fillRect(x,y,2,2);
        }
    }

    private void drawMenu(Graphics2D g) {
        g.setColor(new Color(255, 40, 65)); g.setFont(titleFont);
        centered(g, "CRIMSON PROTOCOL", 235);
        g.setColor(Color.WHITE); g.setFont(uiFont);
        centered(g, "SURVIVE THE DRONE SWARM", 285);
        g.setColor(new Color(170,180,200)); g.setFont(new Font("Monospaced", Font.PLAIN, 14));
        centered(g, "WASD / ARROWS  MOVE     SPACE  FIRE     SHIFT  BOOST", 355);
        g.setColor(new Color(255,70,90)); centered(g, "PRESS ENTER TO DEPLOY", 425);
        g.setColor(new Color(90,100,120)); centered(g, "JAVA 17  •  JAVA2D  •  BUILD 1.0", 570);
    }

    private void drawHud(Graphics2D g) {
        g.setFont(uiFont); g.setColor(Color.WHITE);
        g.drawString("SCORE  " + score, 24, 30);
        g.drawString("WAVE  " + wave, 24, 55);
        g.drawString("INTEGRITY", W-220, 30);
        g.setColor(new Color(55,25,35)); g.fillRoundRect(W-220, 42, 190, 14, 8, 8);
        g.setColor(player.hp > 35 ? new Color(255,50,75) : Color.ORANGE);
        g.fillRoundRect(W-220, 42, 190*player.hp/100, 14, 8, 8);
        if (bannerTicks > 0) {
            g.setFont(new Font("Monospaced", Font.BOLD, 24)); g.setColor(new Color(255,70,90, Math.min(255,bannerTicks*3)));
            centered(g, banner, 115);
        }
    }

    private void overlay(Graphics2D g, String title, String subtitle) {
        g.setColor(new Color(0,0,0,190)); g.fillRect(0,0,W,H);
        g.setFont(titleFont); g.setColor(new Color(255,55,75)); centered(g,title,H/2-25);
        g.setFont(uiFont); g.setColor(Color.WHITE); centered(g,subtitle,H/2+30);
    }
    private void centered(Graphics2D g, String s, int y) { g.drawString(s, (W-g.getFontMetrics().stringWidth(s))/2, y); }

    @Override public void keyPressed(KeyEvent e) {
        int k=e.getKeyCode(); if(k<keys.length) keys[k]=true;
        if(k==KeyEvent.VK_ENTER && (state==GameState.MENU || state==GameState.GAME_OVER)) startGame();
        else if(k==KeyEvent.VK_P && state==GameState.PLAYING) state=GameState.PAUSED;
        else if(k==KeyEvent.VK_P && state==GameState.PAUSED) state=GameState.PLAYING;
        else if(k==KeyEvent.VK_ESCAPE && state==GameState.PLAYING) state=GameState.PAUSED;
    }
    @Override public void keyReleased(KeyEvent e) { int k=e.getKeyCode(); if(k<keys.length) keys[k]=false; }
    @Override public void keyTyped(KeyEvent e) {}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("CRIMSON PROTOCOL");
            Game game = new Game();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setContentPane(game); frame.pack(); frame.setResizable(false);
            frame.setLocationRelativeTo(null); frame.setVisible(true);
            game.requestFocusInWindow();
        });
    }
}
