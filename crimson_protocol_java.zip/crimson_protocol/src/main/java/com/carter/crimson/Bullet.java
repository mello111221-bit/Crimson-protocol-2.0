package com.carter.crimson;
import java.awt.*;
final class Bullet {
    double x,y,vx,vy; boolean friendly,dead;
    Bullet(double x,double y,double vx,double vy,boolean friendly){this.x=x;this.y=y;this.vx=vx;this.vy=vy;this.friendly=friendly;}
    void update(){x+=vx;y+=vy;}
    void draw(Graphics2D g){
        g.setColor(friendly?new Color(255,90,110):new Color(255,180,65));
        g.fillRoundRect((int)x-3,(int)y-9,6,18,5,5);
    }
}
