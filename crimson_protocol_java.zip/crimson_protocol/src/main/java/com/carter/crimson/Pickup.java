package com.carter.crimson;
import java.awt.*;
final class Pickup {
    double x,y; Pickup(double x,double y){this.x=x;this.y=y;}
    void draw(Graphics2D g){
        g.setColor(new Color(70,255,170,65));g.fillOval((int)x-15,(int)y-15,30,30);
        g.setColor(new Color(70,255,170));g.drawOval((int)x-10,(int)y-10,20,20);
        g.drawLine((int)x-6,(int)y,(int)x+6,(int)y);g.drawLine((int)x,(int)y-6,(int)x,(int)y+6);
    }
}
